# Contents
- About
- Available Stickers
- Fonts Used
- Contact/Feedback
- Changelog


# About
Laid-back Altina 2 or "YuruTina 2" stickers by Nihon Falcom (v1.00)
English Translation/Cleaning/Editing by @SethC1995 (u/selentoanuri)
Website: https://sethclydesdale.github.io/projects/falcom-stickers/laid-back-altina-2/

You are free to use these stickers on twitter, discord, etc. for whenever you need to add some Altina flair to your messages! Please also support Nihon Falcom's lovely work by buying the original YuruTina 2 stickers from the LINE store. 
https://store.line.me/stickershop/product/17261152/en

I never thought we'd get another set of Altina stickers, but here we are! Who knows..? Maybe a 3rd set is a possibility as well...
..Still waiting on YuruTio though... T_T


# Available Stickers
- Clean: Stickers without any texts and some effects removed; can be used as is or for translations into yet another language.
- English: English translated stickers
- Japanese: Original Japanese stickers


# Fonts Used
Main: Wild Words (#000 20-24px, may vary; Smooth outline #FFF)
SFX: Another (same settings, variable font size, color)


# Contact/Feedback
If you'd like to contact me to report a mistake or provide feedback, feel free to DM/PM me on:

Twitter: @SethC1995
Reddit: u/selentoanuri


# Changelog

## v1.00 (11/06/2021)
Initial release! Enjoy Altina!!
