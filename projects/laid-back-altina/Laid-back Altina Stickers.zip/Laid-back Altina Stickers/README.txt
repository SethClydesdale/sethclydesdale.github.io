# Contents
- About
- Available Stickers
- Fonts Used
- About Translation Notes
- Contact/Feedback
- Changelog


# About
Laid-back Altina or "YuruTina" stickers by Nihon Falcom (v1.01)
English Translation/Cleaning/Editing by @SethC1995 (u/selentoanuri)
Website: https://sethclydesdale.github.io/projects/laid-back-altina/

Now you can enjoy Laid-back Altina in English with 25% MORE PANCAKES!

You are free to use these stickers on twitter, discord, etc. I ask for nothing in return, save for spreading the word of Altina and her undying love of pancakes and sweets...with stickers! (though if you really want to, I'll gladly accept the Altina figure from Kotobukiya *wink wink* ...joking, a little)

Please also support Nihon Falcom's lovely work by buying the original YuruTina stickers from the LINE store. 
https://store.line.me/stickershop/product/7449307/en

Maybe if they get a surge in sales we'll get YuruTina Vol.2!? ...I wish.. *a single tear flows down my cheek, landing atop a stack of Recette's delicious, diabetes-inducing, pancakes*
...Hell, I'd love to see YuruTio..or a YuruTio x YuruMishy crossover!! ..THERE'S BEEN 8 YURUMISHY SETS... WHY HASN'T TIO APPEARED IN ONE YET FALCOM-SAMA!? WHYYYYYYY--

Ahem.. excuse me. Lastly, if you reupload this for whatever reason, please preseve this readme, so that others may enjoy my insane banter. (then again, you may be doing them a favor by saving them from reading this)


# Available Stickers
- Clean: Stickers without any texts.. put whatever you want on them or use them as is! (or translate into another language)
- English: English translated stickers.. Use 'em with your English speaking friends!
- Japanese: Original Japanese stickers.. Tsukau 'em with your Nihongo speaking tomodachis! (...I'm sorry you had to read that)
- Pancakes: Original pancake edits, by yours truly, due to a lack of pancakes on Falcom's part. Available in English and Japanese under the "Altina & Pancakes" and "アルティナとパンケーキ" folders respectively.
- Twitter: Clean/English/Japanese stickers with the canvas resized to 600x320, to avoid Twitter's horrible image stretching. With more room, some English texts were repositioned/changed.


# Fonts Used
Common: Wild Words (#000 24px, may vary; Glow (for outline to improve contrast on dark BGs): #FFF, offsets 0, opacity 100, softness 1)
SFX: Another (same settings, variable font size, color)

Some texts which were highlighted with #06101C in the original Japanese stickers are preserved in the English stickers as well.

Japanese パンケーキ Stickers Font: UD Digi Kyokasho N-B (if there's a better, more fitting font, let me know and I'll remake them)


# About Translation Notes
Contains raw Japanese texts and translations, plus the insane thoughts of the crazy person who sacrificed some of his pancakes to Altina to bring you these in English.

Feel free to use these notes if translating into yet another language.


# Contact/Feedback
If you'd like to contact me or provide feedback, feel free to DM/PM me on:

Twitter: @SethC1995
Reddit: u/selentoanuri

I am still new to translating, so if I have made any mistakes, do feel free to let me know and I'll correct them.


# Changelog

## v1.01
- added changelog to readme. (yes, this -- the thing you're reading now)
- fixed stray pixels on 036-en and 036-clean left from erasure.
- updated main description in readme.



----------



パンケーキはすごくおいしいです…
そして、アルティナちゃんがとてもかわいいですね(≧▽≦)
アディオス！(^_^)/~

セス
